// DetalleProducto.js
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useAppContext } from '../context/context';

function DetalleProducto() {
  const { id } = useParams();
  const { categorias, setCategorias } = useAppContext();
  const [producto, setProducto] = useState(null);

  useEffect(() => {
    const fetchProducto = async () => {
      try {
        const response = await axios.get(`https://dummyjson.com/products/${id}`);
        setProducto(response.data);
      } catch (error) {
        console.error('Error fetching product:', error);
      }
    };

    fetchProducto();
  }, [id]);
console.log(producto);
  if (!producto) {
    return <div>Cargando...</div>;
  }

  return (
    <div>
      <h1>Detalle del Producto</h1>
      <div className="detalle">
        <h2>{producto.title}</h2>
        <p>{producto.description}</p>
        <p>Precio: ${producto.price}</p>
        <p>Categoría: {producto.category}</p>
        {/* Agrega más detalles del producto si es necesario */}
      </div>
    </div>
  );
}

export default DetalleProducto;
