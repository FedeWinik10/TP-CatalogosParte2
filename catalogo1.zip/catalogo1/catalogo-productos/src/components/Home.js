import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAppContext } from '../context/context';
import { Carousel, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';

function Home() {
  const { categorias, setCategorias } = useAppContext();
  const [productosAleatorios, setProductosAleatorios] = useState([]);
  const [productosDescuento, setProductosDescuento] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
     

        const productosResponse = await axios.get('https://dummyjson.com/products');
        const productosData = productosResponse.data.products;
        setProductosAleatorios(productosData);

        // Obtener 6 productos aleatorios diferentes
        const randomProductos = [];
        while (randomProductos.length < 6) {
          const randomIndex = Math.floor(Math.random() * productosData.length);
          const randomProducto = productosData[randomIndex];
          if (!randomProductos.some((p) => p.id === randomProducto.id)) {
            randomProductos.push(randomProducto);
          }
        }
        setProductosDescuento(randomProductos);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [setCategorias]);

  return (
    <div>
      <div className="categorias">
        <ul>
          {/* Renderiza tus categorías aquí si es necesario */}
          {categorias.map((categoria) => (
            <li key={categoria}>{categoria}</li>
          ))}
        </ul>
      </div>
      <div className="productos">
        <Carousel>
          {productosAleatorios.map((producto) => (
            <Carousel.Item key={producto.id}>
              <Link to={`/productos/${producto.id}`}>
                <img
                  height={400}
                  className="d-block w-100"
                  src={producto.thumbnail}
                  alt={producto.title}
                />
              </Link>
            </Carousel.Item>
          ))}
        </Carousel>
      </div>
      {productosDescuento.length > 0 && (
        <div className="descuento">
          <h2>Productos en Descuento</h2>
          {productosDescuento.map((productoDescuento) => (
            <Card key={productoDescuento.id} style={{ width: '18rem' }}>
              <Card.Img variant="top" src={productoDescuento.thumbnail} />
              <Card.Body>
                <Card.Title>{productoDescuento.title}</Card.Title>
                <Card.Text>{productoDescuento.description}</Card.Text>
                <p>Precio: ${productoDescuento.price}</p>
                <Link to={`/productos/${productoDescuento.id}`}>
                  <Button variant="primary">Comprar ahora</Button>
                </Link>
              </Card.Body>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

export default Home;
