

import { createContext, useContext, useState } from 'react';

const AppContext = createContext();

export const useAppContext = () => useContext(AppContext);

export const AppProvider = ({ children }) => {
  const [categorias, setCategorias] = useState([]);
  const [productosAleatorios, setProductosAleatorios] = useState([]);

  const contextValue = {
    categorias,
    setCategorias,
    productosAleatorios,
    setProductosAleatorios,
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
};
