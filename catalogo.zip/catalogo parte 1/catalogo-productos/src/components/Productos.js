// Productos.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useAppContext } from '../context/context';
import { Card, Button } from 'react-bootstrap';
import Col from 'react-bootstrap/Col';
import Row from 'react-bootstrap/Row';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';


function Productos() {
  const { categorias, setCategorias } = useAppContext();
  const [productos, setProductos] = useState([]);
  const [filtroCategoria, setFiltroCategoria] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Obtener productos
        const productosResponse = await axios.get('https://dummyjson.com/products');
        setProductos(productosResponse.data.products);

        // Obtener categorías
        const categoriasResponse = await axios.get('https://dummyjson.com/products/categories');
        setCategorias(categoriasResponse.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [setCategorias]);

  const filtrarPorCategoria = (categoria) => {
    setFiltroCategoria(categoria);
  };

  // Verificar que productos sea un array antes de intentar el mapeo
  const productosFiltrados = Array.isArray(productos)
    ? filtroCategoria
      ? productos.filter((producto) => producto.category === filtroCategoria)
      : productos
    : [];

    return (
      <div>
    
        <div>
          <label>Filtrar por Categoría:</label>
          <select onChange={(e) => filtrarPorCategoria(e.target.value)}>
            <option value="">Todas</option>
            {categorias.map((categoria) => (
              <option key={categoria} value={categoria}>
                {categoria}
              </option>
            ))}
          </select>
        </div>
        <Row xs={1} md={2} lg={3} xl={4} className="g-4 justify-content-md-between">
          {productosFiltrados.map((producto) => (
            <Col key={producto.id}>
              <Card>
                <Card.Img variant="top" src={producto.thumbnail} className="card-img" />
                <Card.Body>
                  <Card.Title>{producto.title}</Card.Title>
                  <Card.Text>{producto.description}</Card.Text>
                  <p>Precio: ${producto.price}</p>
                  <Link to={`/producto/${producto.id}`}>
                    <Button variant="primary">Ver detalles</Button>
                  </Link>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      </div>
    );
  }

export default Productos;
