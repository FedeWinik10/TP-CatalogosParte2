import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAppContext } from '../context/context';
import { Carousel, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.css';

function Home() {
  const { categorias, setProductosAleatorios, setCategorias } = useAppContext();
  const [productosAleatorios, setProductosAleatoriosLocal] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Obtener categorías
        const categoriasResponse = await axios.get('https://dummyjson.com/products/categories');
        const categoriasData = categoriasResponse.data;

        // Guardar categorías en el contexto
        setCategorias(categoriasData);

        // Obtener productos aleatorios
        const productosResponse = await axios.get('https://dummyjson.com/products');
        const productosData = productosResponse.data.products;

        // Guardar productos aleatorios en el contexto y localmente
        setProductosAleatorios(productosData);
        setProductosAleatoriosLocal(productosData);
      } catch (error) {
        if (error.response && error.response.status === 429) {
          console.warn('Too many requests. Waiting and retrying...');
          await new Promise(resolve => setTimeout(resolve, 5000));
          fetchData();
        } else {
          console.error('Error fetching data:', error);
        }
      }
    };

    fetchData();
  }, [setCategorias, setProductosAleatorios]);

  const productoDescuento = productosAleatorios[Math.floor(Math.random() * productosAleatorios.length)];

  return (
    <div>

      <div className="categorias">
        <ul>{/* Renderiza tus categorías aquí */}</ul>
      </div>
      <div className="productos">
        <Carousel>
          {productosAleatorios.map((producto) => (
            <Carousel.Item key={producto.id}>
              {/* Enlace al detalle del producto */}
              <Link to={`/productos/${producto.id}`}>
                <img
                  height={400}
                  className="d-block w-100"
                  src={producto.thumbnail}
                  alt={producto.title}
                />
              </Link>
            </Carousel.Item>
          ))}
        </Carousel>
      </div>
      {productoDescuento && (
        <div className="descuento">
          <h2>Producto en Descuento</h2>
          <Card style={{ width: '18rem' }}>
            <Card.Img variant="top" src={productoDescuento.thumbnail} />
            <Card.Body>
              <Card.Title>{productoDescuento.title}</Card.Title>
              <Card.Text>{productoDescuento.description}</Card.Text>
              <p>Precio: ${productoDescuento.price}</p>
              <Button variant="primary">Comprar ahora</Button>
            </Card.Body>
          </Card>
        </div>
      )}
    </div>
  );
}

export default Home;
